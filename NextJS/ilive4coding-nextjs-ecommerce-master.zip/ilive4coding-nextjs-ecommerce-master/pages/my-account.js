import React from "react";

export default function MyAccount() {
  return <div>My Account</div>;
}
