import React from "react";

export default function checkout() {
  return <div>Checkout</div>;
}
