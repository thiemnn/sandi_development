import React from "react";

export default function OurServices() {
  return <div>Our Services</div>;
}
