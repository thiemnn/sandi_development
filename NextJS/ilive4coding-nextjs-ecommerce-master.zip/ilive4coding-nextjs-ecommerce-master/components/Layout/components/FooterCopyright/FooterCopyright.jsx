import React from "react";

export default function FooterCopyright() {
  return (
    <div className="footer-copyright">
      <p className="footer-company">
        All Rights Reserved. &copy; 2018 <a href="#">ThewayShop</a> Design By :
        <a href="https://html.design/">html design</a>
      </p>
    </div>
  );
}
